function b(){
	document.write("b.js");
}