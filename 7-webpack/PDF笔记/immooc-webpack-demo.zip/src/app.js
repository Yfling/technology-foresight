 import Layer from './components/layer/layer.js'
 import './css/common.css';


 const App = function(){
    var app = document.getElementById("app");
    var layer = new Layer();
    app.innerHTML = layer.tpl({
        name:'john',
        arr:['happy','sad','didi']
    });
 }
 
 new App();