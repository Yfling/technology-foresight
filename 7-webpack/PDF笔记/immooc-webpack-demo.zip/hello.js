require("style-loader!css-loader!./style.css");
function hello(){
	document.write("hello word");
}
hello();

